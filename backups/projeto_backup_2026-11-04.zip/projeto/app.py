from flask import Flask, render_template
from src.mocks import KIMONO

app = Flask(__name__)

@app.route("/")
def inicio():
    return "no ar!" 

@app.route("/kimonos")
def lista_kimonos():
    return render_template("lista.html", kimonos=KIMONO)